jQuery(document).ready(function($){
  
  var isRetina = false;
  var isMobile = false;
  var fixedElement;

  var checkMobile = function(){
    if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
      isMobile = true;
    }
  }

  var retinafy = function(){
    if (window.devicePixelRatio >= 1.2) 
      isRetina = true;
    else
      return;

    $('*').each(function(){
      var bgImg = $(this).css('background-image');
      if (bgImg !== 'none') {
        $(this).css('background-image', bgImg.replace('.jpg', '@2x.jpg'))
      }
    })
  }

  var coverEffect = function(){
    var $cover = $('.cover');
    var $next = $cover.next();
    if ($(document).scrollTop() < $next.outerHeight())
      $next.addClass('fixed');
    else
      $next.removeClass('fixed');

    var $grid = $cover.find('.grid');
    var range = 200;
    var newY = $(document).scrollTop() / $cover.outerHeight() * -range;
    $grid.css({'-webkit-transform':'translateY(' + newY + 'px)',
               '-ms-transform':'translateY(' + newY + 'px)',
               'transform':'translateY(' + newY + 'px)'});
  }

  var parallax = function(){

    $('.fixed-img').each(function(i, el){
      var $this = $(this);
      var diff = $(document).scrollTop() + $(window).innerHeight() - $this.offset().top;
      if (diff >= 0 && diff <= $this.outerHeight() + $(window).innerHeight()) {
        var ratio = diff / ($this.outerHeight() + $(window).innerHeight());
        var range = 20
        if (!this.cssY)
          this.cssY = parseInt($this.css('background-position-y'));
        var parallaxY = this.cssY + ratio * range - range/2;
        $this.css('background-position-y', parallaxY + '%');
      }
    });

  }

  var onScroll = function(e){
    parallax();
    coverEffect();
  }

  checkMobile();
  retinafy();

  $('html').addClass('fullheight');
  coverEffect();
  $(document).scroll(onScroll)

});