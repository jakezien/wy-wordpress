	<footer></footer>
</body>
</html>
<?php wp_footer(); ?>